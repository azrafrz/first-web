document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Menghentikan pengiriman form

    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    // Periksa proses login
    if (username === 'admin' && password === 'password') {
        // Jika login berhasil, alihkan ke halaman isi
        window.location.href = 'index.html';
    } else {
        // Jika login gagal, tampilkan pesan kesalahan
        alert('Login gagal. Silakan coba lagi.');
    }
});
