let message = 'Hi. Welcome to my Website!';
alert(message);
